from ursina import *
from ursina.prefabs.first_person_controller import FirstPersonController
import random
import math

class HorrorGame(Entity):
    def __init__(self):
        super().__init__()
        # Set up the player with increased speed and jump height.
        self.player = FirstPersonController()
        self.player.y = 1  # Start above ground.
        self.player.speed = 17
        self.player.jump_height = 5
        self.previous_position = self.player.position
        
        # Create a basic house for ambiance.
        self.house = self.create_house()
        
        # Set up phone textbox.
        self.phone_textbox = Text(text='', position=(-0.5, 0.4), scale=2, visible=False)
        
        # A long list of dialogues that progress from caring to disinterested.
        self.phone_dialogues = [
            "Hey, just checking in. Everything okay?",
            "You sound a bit off—are you alright?",
            "I'm really worried about you. Please let me know if you need help.",
            "Are you safe? It's been a while since I heard from you.",
            "I know things are tough, but I'm here if you need someone.",
            "Don't forget to take care of yourself out there.",
            "It seems like you're struggling—hang in there.",
            "I just wanted to remind you that you're not alone.",
            "Is there anything I can do to help?",
            "Sometimes talking can make things a little easier.",
            "Remember, I'm just a phone call away.",
            "I hope you're finding some hope even in the dark times.",
            "I know it's hard, but please don't give up.",
            "Your well-being matters to me.",
            "Take it one step at a time.",
            "I wish I could be there with you.",
            "Life can be challenging, but you have the strength to overcome it.",
            "I believe in you.",
            "Sometimes the hardest battles are given to the strongest people.",
            "Stay safe, okay?",
            "I really hope you're doing alright.",
            "You're not alone in this.",
            "It's okay to feel overwhelmed sometimes.",
            "I'm always here if you need someone to talk to.",
            "I miss hearing from you.",
            "Just checking in again.",
            "I worry about you, please take care.",
            "I hope you found some comfort today.",
            "Remember, you're important to me.",
            "I understand if you need some space, but I'm still here.",
            "If you ever want to talk, I'm listening.",
            "I hope things start looking up soon.",
            "Take a deep breath and try to relax.",
            "Maybe you should take a break, even if it's just for a moment.",
            "It's okay not to be okay sometimes.",
            "I'm here, no matter what.",
            "Just wanted to say I care.",
            "Hope you're managing alright.",
            "Don't forget to smile, even if it's just for a moment.",
            "Your strength is inspiring.",
            "I believe brighter days are ahead.",
            "I hope you remember that you matter.",
            "Stay strong, and remember you're loved.",
            "Sometimes a little rest can make all the difference.",
            "I'm still here, always.",
            "Maybe try to take it easy today.",
            "I wonder how you're really doing.",
            "I know things are rough, but I'm rooting for you.",
            "Please let me know if you need anything.",
            "I'm starting to feel like maybe I'm just talking to myself...",
            "It seems like my calls don't really matter anymore.",
            "Maybe you don't care as much as I hoped.",
            "I guess I'll keep trying, even if it's one-sided.",
            "Not much to say these days...",
            "I don't know if you're even listening.",
            "Maybe this is all just background noise to you.",
            "Well, I guess I'll stop calling now.",
            "Take care, I guess...",
            "..."
        ]
        # Append 100 additional lines to simulate extended dialogue.
        self.phone_dialogues += [f"Extended dialogue line {i}" for i in range(1, 101)]
        
        self.dialogue_index = 0
        self.phone_active = False
        
        self.change_counter = 0
        self.step_counter = 0
        self.time_since_last_call = 0  # Elapsed time for phone calls.
        self.total_time = 0            # Total elapsed game time.
        window.color = color.black

        # Add lighting.
        DirectionalLight()

        # Add a floor with collision.
        floor = Entity(model='plane', scale=(25, 1, 25), position=(0, -0.1, 0), color=color.gray)
        floor.collider = 'box'

        # Set camera position.
        self.camera_position = Vec3(0, 1, 5)

        # Create the fixed, linear obstacle course.
        self.create_obby()

        # Store spawn position for respawning (first platform's position).
        self.spawn_position = self.platforms[0].position if self.platforms else Vec3(0, 1, 0)

    def create_house(self):
        # Dummy house for ambiance.
        house_parent = Entity()
        for x in range(-5, 6):
            for z in range(-5, 6):
                pass
        return house_parent

    def create_obby(self):
        """
        Creates a fixed, linear obstacle course along the x-axis.
        Uses sine and cosine functions to vary platform height (y-axis) and lateral position (z-axis).
        """
        self.platforms = []
        num_platforms = 45
        gap = 11  # Distance between platforms along the x-axis.
        for i in range(num_platforms):
            x = 10 + i * gap
            y = 1 + 0.5 * math.sin(i * math.pi / 1)   # Vary height.
            z = 2 * math.cos(i * math.pi / 2)           # Vary lateral position.
            pos = Vec3(x, y, z)
            self.create_platform(pos, color=color.blue)

    def create_platform(self, position, color=color.blue):
        platform = Entity(model='cube', color=color, scale=(5, 0.5, 5), position=position)
        platform.collider = 'box'
        self.platforms.append(platform)

    def update(self):
        # Update total elapsed time.
        self.total_time += time.dt

        # If player falls off the platforms, reset to spawn.
        if self.player.position.y < -100:
            self.player.position = self.spawn_position

        # Increase step counter as the player moves.
        if self.player.position != self.previous_position:
            self.step_counter += 1
            self.previous_position = self.player.position

        # Trigger a phone call based on steps.
        if not self.phone_active and self.step_counter > 150:
            self.trigger_phone_call()
            self.step_counter = 0

        # Trigger phone calls based on elapsed time (1–3 minutes).
        self.time_since_last_call += time.dt
        if self.time_since_last_call > random.uniform(60, 180):
            self.trigger_phone_call()
            self.time_since_last_call = 0

        # Slowly drain colors (very gradual tint).
        if self.change_counter > 5:
            self.subtle_changes()

        # After 15 minutes, trigger random glitch effects.
        if self.total_time > 6 * 60:
            if random.random() < 0.005:  # small chance each frame.
                self.trigger_glitch_effect()

        # After 10 minutes, start applying camera glitch effects.
        if self.total_time > 10 * 60:
            self.apply_camera_glitch()

    def trigger_phone_call(self):
        # Select dialogue based on the current dialogue index.
        if self.dialogue_index < len(self.phone_dialogues):
            dialogue = self.phone_dialogues[self.dialogue_index]
        else:
            dialogue = "..."
        # Apply a subtle misspelling effect.
        self.phone_textbox.text = self.misspell_text(dialogue)
        self.phone_textbox.visible = True
        self.phone_active = True
        invoke(self.hide_phone_text, delay=3)
        self.dialogue_index += 1
        self.change_counter += 1

    def hide_phone_text(self):
        self.phone_textbox.visible = False
        self.phone_active = False

    def subtle_changes(self):
        # Slowly drain colors with a very slight tint.
        for platform in self.platforms:
            platform.color = platform.color.tint(0.995)
        self.change_counter = 0

    def trigger_glitch_effect(self):
        # Randomly choose a platform to flicker.
        glitch_entity = random.choice(self.platforms)
        original_visibility = glitch_entity.visible
        glitch_entity.visible = False
        # Optionally spawn a temporary "glitch" entity.
        glitch = Entity(model='cube', color=color.random_color(), scale=(3, 0.3, 3),
                        position=glitch_entity.position + Vec3(0, random.uniform(0, 2), 0))
        invoke(lambda: setattr(glitch, 'enabled', False), delay=random.uniform(0.2, 0.5))
        # Restore original visibility shortly after.
        invoke(lambda: setattr(glitch_entity, 'visible', original_visibility), delay=random.uniform(0.2, 0.5))

    def apply_camera_glitch(self):
        # Apply a small random jitter to the camera's position.
        jitter = Vec3(random.uniform(-0.001, 0.001),
                      random.uniform(-0.001, 0.001),
                      0)
        camera.position += jitter
        # Optionally, also jitter the camera's rotation slightly.
        

    def misspell_text(self, text):
        # Introduce minor character alterations for a subtle effect.
        text_list = list(text)
        for _ in range(random.randint(1, 3)):
            index = random.randint(0, len(text_list) - 1)
            if text_list[index].isalpha():
                if random.random() < 0.2:
                    text_list[index] = text_list[index].lower() if text_list[index].isupper() else text_list[index].upper()
            elif text_list[index] in '.,' and random.random() < 0.5:
                text_list[index] = ''
            else:
                text_list.insert(index, random.choice('.,'))
        return ''.join(text_list)

app = Ursina()
game = HorrorGame()
app.run()
