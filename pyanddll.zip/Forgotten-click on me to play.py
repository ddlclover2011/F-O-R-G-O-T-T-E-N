from ursina import *
from ursina.prefabs.first_person_controller import FirstPersonController
import random
import math
import time

class HorrorGame(Entity):
    def __init__(self):
        super().__init__()
        # Set up the player
        self.player = FirstPersonController()
        self.player.y = 2
        self.player.speed = 17
        self.player.jump_height = 5
        self.spawn_position = Vec3(0, 2, 0)
        if self.player.y < -50:
            self.player.y = 200
           
        # Glitch cube
        self.glitch_cube = Entity(model='cube', color=color.red, scale=2, visible=False)

        # Game state
        self.total_time = 0
        self.time_since_last_glitch = 0
        self.level = 1
        self.dialogue_index = 0
        self.phone_active = False
        self.phone_textbox = Text(text='', position=(-0.5, 0.4), scale=2, visible=False)
        self.phone_dialogues = self.load_original_dialogues()

        # Lighting and environment setup
        DirectionalLight()
        self.create_terrain()
        self.create_obby(self.level)

        # Start the glitch loop
        self.start_glitch_loop()

        # Gradual color loss via tint
        self.tint_value = 1
        self.tint_rate = 0.055  # Speed of tinting (color loss)

        # Track time for dialogue events
        self.dialogue_timer = 0
        self.dialogue_interval = 15  # Show a new line every 15 seconds

        # Event for phone glitching or corruption
        self.phone_glitch_timer = 0
        self.phone_glitch_interval = random.uniform(60, 120)  # Glitch happens every 1-2 minutes
        self.phone_glitch_state = False

    def create_terrain(self):
        """Creates the terrain with hills and variation."""
        self.terrain = Entity(model='plane', color=color.green, scale=(200, 1, 200), position=(0, -1, 0), collider='mesh')

    def create_obby(self, level=1):
        for num in range(level):
            """Creates a progressively harder obstacle course."""
            self.platforms = []
            num_platforms = 20 + (level+1 * 3)
            gap = 7 - (level * 0.5)
            for i in range(num_platforms):
                x = i * gap
                y = 1 + 2.5 * math.sin(i * math.pi / 3)
                z = 4 * math.cos(i * math.pi / 2)
                pos = Vec3(x, y, z)
                self.create_platform(pos, color=color.blue)

            self.end_point = Entity(model='cube', color=color.green, scale=3, position=self.platforms[-1].position + Vec3(10, 3, 0))
            self.end_point.collider = 'box'

    def create_platform(self, position, color=color.blue):
        """Creates an individual platform."""
        platform = Entity(model='cube', color=color, scale=(5, 0.5, 5), position=position)
        platform.collider = 'box'
        self.platforms.append(platform)

    def start_glitch_loop(self):
        """Starts the glitch cube loop."""
        invoke(self.trigger_glitch, delay=random.uniform(5, 15))

    def trigger_glitch(self):
        """Makes the glitch cube randomly appear for a split second."""
        if random.random() < 0.5:
            random_x = self.player.x + random.uniform(-10, 10)
            random_z = self.player.z + random.uniform(-10, 10)
            self.glitch_cube.position = Vec3(random_x, self.player.y + random.uniform(-1, 1), random_z)
            self.glitch_cube.visible = True
            invoke(self.hide_glitch, delay=0.1)

        invoke(self.trigger_glitch, delay=random.uniform(5, 15))

    def hide_glitch(self):
        """Hides the glitch cube."""
        self.glitch_cube.visible = False

    def load_original_dialogues(self):
        """Loads the original 250 horror dialogue lines."""
        return [
            "Hey, just checking in. Everything okay?",
            "You sound a bit off—are you alright?",
            "I'm really worried about you. Please let me know if you need help.",
            "Are you safe? It's been a while since I heard from you.",
            "I know things are tough, but I'm here if you need someone.",
            "Don't forget to take care of yourself out there.",
            "I just wanted to remind you that you're not alone.",
            "Is there anything I can do to help?",
            "Sometimes talking can make things a little easier.",
            "Remember, I'm just a phone call away.",
            "I hope you're finding some hope even in the dark times.",
            "I know it's hard, but please don't give up.",
            "Your well-being matters to me.",
            "Take it one step at a time.",
            "I wish I could be there with you.",
            "Life can be challenging, but you have the strength to overcome it.",
            "I believe in you.",
            "Sometimes the hardest battles are given to the strongest people.",
            "Stay safe, okay?",
            "I really hope you're doing alright.",
            "You're not alone in this.",
            "It's okay to feel overwhelmed sometimes.",
            "I'm always here if you need someone to talk to.",
            "I miss hearing from you.",
            "Just checking in again.",
            "I worry about you, please take care.",
            "I hope you found some comfort today.",
            "Remember, you're important to me.",
            "I understand if you need some space, but I'm still here.",
            "If you ever want to talk, I'm listening.",
            "I hope things start looking up soon.",
            "Take a deep breath and try to relax.",
            "Maybe you should take a break, even if it's just for a moment.",
            "It's okay not to be okay sometimes.",
            "I'm here, no matter what.",
            "Just wanted to say I care.",
            "Hope you're managing alright.",
            "Don't forget to smile, even if it's just for a moment.",
            "Your strength is inspiring.",
            "I believe brighter days are ahead.",
            "I hope you remember that you matter.",
            "Stay strong, and remember you're loved.",
            "I'm still here, always.",
            "Maybe try to take it easy today.",
            "I wonder how you're really doing.",
            "I know things are rough, but I'm rooting for you.",
            "Please let me know if you need anything.",
            "I'm starting to feel like maybe I'm just talking to myself...",
            "It seems like my calls don't really matter anymore.",
            "Maybe you don't care as much as I hoped.",
            "I guess I'll keep trying.",
            # Breaking the fourth wall
            "Do you remember what this game was called?",
            "Why can't I remember it anymore?",
            "This was supposed to be just a game, right?",
            "What happened to the world? Why is it breaking?",
            "It feels like everything is decaying, like the game is... forgetting itself.",
            "Can you hear that? It's the sound of everything falling apart.",
            "I don't know if I can keep going...",
            "Can you hear me? Can you even see me anymore?",
            "I used to be so clear about what I was supposed to do.",
            "Now, it's all fading. The levels, the goals, the purpose... gone.",
            "Was this always the way it was supposed to be?",
            "I don't remember what we're even trying to achieve.",
            "Did you forget? Was it always this way?",
            "This isn't the game I thought it was. This isn't *our* game.",
            "I don't even know if there's an end anymore.",
            "Are you still playing? Or have you given up too?",
            "I think it's too late for any of us.",
            "Can you even hear this dialogue? Or has it all been corrupted?",
            "It's fading away. The world... is fading away.",
            "I think we both know... this is the end."
        ]

    def update(self):
        """Called every frame to update the game."""
        self.total_time += time.dt  # Track total time in the game
        if self.player.y < -50:
            self.player.y = 200
        # Apply gradual tint (color loss) effect
        if self.tint_value < 1:
            self.tint_value += self.tint_rate * time.dt
            self.tint_value = min(self.tint_value, 1)  # Clamp to 1

            # Apply tint to the environment (fading effect)
            self.terrain.tint = Vec3(self.tint_value, self.tint_value, self.tint_value)  # Gradual color loss

        # Check if the game time has passed 15 minutes (900 seconds)
        if self.total_time > 900 and not self.glitch_cube.visible:
            self._15min()  # Trigger the glitch cube and color changes after 15 minutes

        # Handle dialogue triggering every 15 seconds
        if self.total_time - self.dialogue_timer >= self.dialogue_interval and self.dialogue_index < len(self.phone_dialogues):
            self.phone_textbox.text = self.phone_dialogues[self.dialogue_index]
            self.phone_textbox.visible = True
            self.dialogue_timer = self.total_time
            self.dialogue_index += 1

        # Phone glitch trigger
        if self.total_time - self.phone_glitch_timer >= self.phone_glitch_interval:
            self.phone_glitch_state = random.choice([True, False])
            self.phone_glitch_timer = self.total_time
            if self.phone_glitch_state:
                self.phone_textbox.text = "ERROR: Glitch detected"
                self.phone_textbox.color = color.red
                self.phone_textbox.visible = True
            else:
                self.phone_textbox.text = self.phone_dialogues[self.dialogue_index] if self.dialogue_index < len(self.phone_dialogues) else "End of Messages"
                self.phone_textbox.color = color.white
                self.phone_textbox.visible = True

    def _15min(self):
        """Appear the glitch cube and apply color loss after 15 minutes."""
        self.glitch_cube.visible = True

        # Gradually fade the entire world to a darker tint
        self.terrain.tint = Vec3(self.tint_value, self.tint_value, self.tint_value)  # Apply tint effect

        # Add any additional behavior after 15 minutes, such as game-ending visuals or actions
        invoke(self.start_shaking, delay=600)  # Start shaking after 10 minutes (600 seconds)

    def start_shaking(self):
        """Makes the window shake after 10 minutes."""
        self.camera.shake(5, 2)

        # After shaking, close the game window
        invoke(self.close_game, delay=2)

    def close_game(self):
        """Closes the game window."""
        application.quit()

# Initialize and run the game
if __name__ == "__main__":
    app = Ursina()
    game = HorrorGame()
    app.run()
